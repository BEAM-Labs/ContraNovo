#!/bin/bash

species=mouse

#specieslist=("bacillus" "clambacteria" "honeybee" "human" "mmazei" "mouse" "ricebean" "tomato" "yeast")

test_path=/mnt/data/oss_beijing/gaozhq/ms_data/9species/test_species/${species}.10k.mgf

CUDA_VISIBLE_DEVICES=7 python -m ContraNovo.ContraNovo  --mode=eval --peak_path=${test_path} --model=/mnt/data/oss_beijing/jinzhi/epoch=11-step=82500.ckpt 2>&1 | tee Eval${species}.log